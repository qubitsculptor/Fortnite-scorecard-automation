# Put your scorecard screenshots here
# Supported formats: PNG, JPG, JPEG

This folder is for storing Fortnite Ballistic scorecard screenshots.

The system will automatically process all images in this folder when you run:
```bash
python cli.py --folder screenshots
```

or use the web interface with:
```bash
streamlit run app.py
```
